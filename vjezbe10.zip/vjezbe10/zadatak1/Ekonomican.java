package zadatak1;

public interface Ekonomican {
    double potrosnjaPoKm();
}
